package com.example.mylauncher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var favRow: RecyclerView
    private lateinit var toolsRow: RecyclerView
    private lateinit var appGrid: RecyclerView
    private lateinit var favTitle: TextView

    private val favAdapter = AppAdapter(::launch, ::showOptions)
    private val toolsAdapter = AppAdapter(::launch, {})
    private val gridAdapter = AppAdapter(::launch, ::showOptions)

    private var allApps: List<AppInfo> = emptyList()
    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    // File picker used by the "Install APK" tool.
    private val apkPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { installApk(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        favTitle = findViewById(R.id.favTitle)
        favRow = findViewById(R.id.favRow)
        toolsRow = findViewById(R.id.toolsRow)
        appGrid = findViewById(R.id.appGrid)

        favRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        favRow.adapter = favAdapter

        toolsRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        toolsRow.adapter = toolsAdapter
        toolsAdapter.submit(buildTools())

        appGrid.layoutManager = GridLayoutManager(this, 6)
        appGrid.adapter = gridAdapter
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        appGrid.scrollToPosition(0)
        firstFocusTarget().requestFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher never exits on Back.
    }

    private fun firstFocusTarget(): RecyclerView = if (favRow.isShown) favRow else toolsRow

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        val pm = packageManager
        val tv = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val mobile = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(tv, 0) + pm.queryIntentActivities(mobile, 0)

        allApps = resolved
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.activityInfo.loadBanner(pm) ?: it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }

        gridAdapter.submit(allApps)
        refreshFavorites()
        appGrid.post { firstFocusTarget().requestFocus() }
    }

    private fun refreshFavorites() {
        val pinned = prefs.getStringSet("favorites", emptySet()).orEmpty()
        val favs = allApps.filter { it.packageName in pinned }
        favAdapter.submit(favs)
        val vis = if (favs.isEmpty()) View.GONE else View.VISIBLE
        favRow.visibility = vis
        favTitle.visibility = vis
    }

    private fun launch(app: AppInfo) {
        if (app.packageName.startsWith(TOOL_PREFIX)) {
            runTool(app.packageName.removePrefix(TOOL_PREFIX))
            return
        }
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
        intent?.let { startActivity(it) }
    }

    private fun showOptions(app: AppInfo) {
        val pinned = prefs.getStringSet("favorites", emptySet()).orEmpty().toMutableSet()
        val isPinned = app.packageName in pinned
        val items = arrayOf(
            if (isPinned) "Remove from favorites" else "Add to favorites",
            "App info",
            "Uninstall"
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        if (isPinned) pinned.remove(app.packageName) else pinned.add(app.packageName)
                        prefs.edit().putStringSet("favorites", pinned).apply()
                        refreshFavorites()
                    }
                    1 -> openAppDetails(app.packageName)
                    2 -> tryStart(
                        Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${app.packageName}"))
                    )
                }
            }
            .show()
    }

    // --------------------------------------------------------------- tools

    private fun buildTools(): List<AppInfo> = listOf(
        tool("tvsettings", "TV Settings", 0xFF3A7BFF.toInt(), android.R.drawable.ic_menu_preferences),
        tool("settings", "Android Settings", 0xFF5B6B8C.toInt(), android.R.drawable.ic_menu_manage),
        tool("dev", "Developer options", 0xFF8E44AD.toInt(), android.R.drawable.ic_menu_edit),
        tool("playstore", "Fix Play Store", 0xFF27AE60.toInt(), android.R.drawable.ic_menu_info_details),
        tool("gms", "Fix Play services", 0xFF16A085.toInt(), android.R.drawable.ic_menu_info_details),
        tool("unknown", "Allow installs", 0xFFE67E22.toInt(), android.R.drawable.ic_menu_add),
        tool("apk", "Install APK file", 0xFFD35400.toInt(), android.R.drawable.ic_menu_search),
        tool("apps", "Manage all apps", 0xFF2C3E50.toInt(), android.R.drawable.ic_menu_manage),
        tool("wifi", "Wi-Fi", 0xFF2980B9.toInt(), android.R.drawable.ic_menu_share)
    )

    private fun tool(id: String, label: String, color: Int, iconRes: Int): AppInfo {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 28f
            setColor(color)
        }
        val fg: Drawable = getDrawable(iconRes)!!.mutate().apply { setTint(Color.WHITE) }
        val layers = LayerDrawable(arrayOf(bg, fg)).apply { setLayerInset(1, 150, 40, 150, 40) }
        return AppInfo(label, TOOL_PREFIX + id, layers)
    }

    private fun runTool(id: String) {
        when (id) {
            "tvsettings" -> tryStart(
                packageManager.getLaunchIntentForPackage("com.cvte.settings"),
                packageManager.getLaunchIntentForPackage("com.cvte.tv.setting"),
                Intent(Settings.ACTION_SETTINGS)
            )
            "settings" -> tryStart(Intent(Settings.ACTION_SETTINGS))
            "dev" -> tryStart(
                Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                Intent(Settings.ACTION_DEVICE_INFO_SETTINGS) // tap "Build" 7 times here
            )
            "playstore" -> openAppDetails("com.android.vending")
            "gms" -> openAppDetails("com.google.android.gms")
            "unknown" -> tryStart(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            "apk" -> {
                if (!packageManager.canRequestPackageInstalls()) {
                    toast("First allow this launcher to install apps")
                    runTool("unknown")
                } else {
                    try {
                        apkPicker.launch(
                            arrayOf("application/vnd.android.package-archive", "application/octet-stream")
                        )
                    } catch (e: ActivityNotFoundException) {
                        toast("No file picker on this TV. Install a file manager app first.")
                    }
                }
            }
            "apps" -> tryStart(
                Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
                Intent(Settings.ACTION_APPLICATION_SETTINGS)
            )
            "wifi" -> tryStart(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    /** Opens the system "App info" page; for a disabled app this page shows an Enable button. */
    private fun openAppDetails(pkg: String) {
        tryStart(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")),
            Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_SETTINGS)
        )
    }

    private fun installApk(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        tryStart(i)
    }

    /** Tries each intent in order and stops at the first one this TV can actually open. */
    private fun tryStart(vararg intents: Intent?) {
        for (i in intents) {
            if (i == null) continue
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // try the next one
            }
        }
        toast("This TV blocks that screen")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val TOOL_PREFIX = "tool:"
    }
}
