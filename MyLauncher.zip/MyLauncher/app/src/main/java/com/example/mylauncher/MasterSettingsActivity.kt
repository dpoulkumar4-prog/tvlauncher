package com.example.mylauncher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.net.NetworkInterface
import java.util.Locale

/**
 * A-tv Settings: a master settings app that does not depend on the TV maker's Settings.
 * It only changes what Android lets a normal app change, and tells you the exact ADB command
 * for the rest.
 */
class MasterSettingsActivity : AppCompatActivity() {

    private lateinit var root: ScrollView
    private val refreshers = mutableListOf<() -> Unit>()
    private val rows = mutableListOf<View>()

    private val grantCmd =
        "adb shell pm grant com.example.mylauncher android.permission.WRITE_SECURE_SETTINGS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(27), dp(48), dp(27))
        }
        root.addView(col)
        setContentView(root)

        col.addView(TextView(this).apply {
            text = "A-tv Settings"
            setTextColor(Color.WHITE)
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Master settings for this TV. Press OK on a line."
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 14f
        })

        // ------------------------------------------------------ Developer
        section(col, "Developer")
        secureToggle(col, "Developer options", "development_settings_enabled")
        secureToggle(col, "USB debugging", Settings.Global.ADB_ENABLED)
        secureToggle(col, "Wireless debugging", "adb_wifi_enabled")
        row(col, "Why do these ask for a command?", { "" }) {
            showCopy(
                "One-time permission",
                "Android only lets an app change these switches after you grant it this permission " +
                    "once from a computer or phone with ADB:\n\n$grantCmd\n\nThen come back here.",
                grantCmd
            )
        }

        // ------------------------------------------------------------ Apps
        section(col, "Apps")
        row(col, "All apps (including disabled)", { "${countApps(false)} on, ${countApps(true)} off" }) {
            showAllApps()
        }
        row(col, "Fix Play Store and Play services", { playState() }) {
            showCopy(
                "Enable Play Store",
                "An app cannot switch these on by itself. Run these two lines with ADB " +
                    "(restart the TV afterwards):\n\n" +
                    "adb shell pm enable com.google.android.gms\n" +
                    "adb shell pm enable com.android.vending",
                "adb shell pm enable com.google.android.gms\nadb shell pm enable com.android.vending"
            )
        }
        row(col, "Install an APK file", { "" }) {
            startActivity(Intent(this, MainActivity::class.java).putExtra("tool", "apk"))
        }

        // ----------------------------------------------------- Network
        section(col, "Network")
        row(col, "IP address", { ipAddress() }) { }
        row(col, "Wi-Fi speed and data used", { "" }) {
            startActivity(Intent(this, CleanActivity::class.java))
        }
        row(col, "Wi-Fi networks (TV maker screen)", { "" }) {
            go(
                Intent(Settings.ACTION_WIFI_SETTINGS),
                packageManager.getLaunchIntentForPackage("com.cvte.settings"),
                packageManager.getLaunchIntentForPackage("com.cvte.tv.setting")
            )
        }

        // ------------------------------------------------------- Sound
        section(col, "Sound")
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        row(col, "Volume up", { "${am.getStreamVolume(AudioManager.STREAM_MUSIC)} / ${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}" }) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        }
        row(col, "Volume down", { "" }) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        row(col, "Mute / unmute", { "" }) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
        }

        // -------------------------------------------- TV maker screens
        section(col, "Picture, input and system (TV maker)")
        row(col, "Picture, sound, channels, inputs", { "Maker settings" }) {
            go(
                packageManager.getLaunchIntentForPackage("com.cvte.settings"),
                packageManager.getLaunchIntentForPackage("com.cvte.tv.setting"),
                packageManager.getLaunchIntentForPackage("com.droidlogic.tvinput")
            )
        }
        row(col, "Date and time", { "" }) { go(Intent(Settings.ACTION_DATE_SETTINGS)) }
        row(col, "Language", { "" }) { go(Intent(Settings.ACTION_LOCALE_SETTINGS)) }
        row(col, "Software update", { "" }) {
            go(packageManager.getLaunchIntentForPackage("com.cvte.tv.systemupgrade"))
        }

        // ------------------------------------------------------ Launcher
        section(col, "A-tv launcher")
        row(col, "Customize wallpaper, colours, layout", { "" }) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        row(col, "Open A-tv home", { "" }) {
            startActivity(Intent(this, MainActivity::class.java))
        }

        // ---------------------------------------------------- About TV
        section(col, "About this TV")
        row(col, "Model", { "${Build.MANUFACTURER} ${Build.MODEL}" }) { }
        row(col, "Android", { "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})" }) { }
        row(col, "Build", { Build.DISPLAY }) { }

        refreshAll()
        rows.firstOrNull()?.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    // ------------------------------------------------------ secure toggles

    private fun canSecure() =
        checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    private fun readGlobal(key: String) = try {
        Settings.Global.getInt(contentResolver, key, 0) == 1
    } catch (e: Exception) {
        false
    }

    private fun secureToggle(parent: LinearLayout, title: String, key: String) {
        row(parent, title, {
            val state = if (readGlobal(key)) "On" else "Off"
            if (canSecure()) state else "$state (needs permission)"
        }) {
            if (!canSecure()) {
                showCopy("Permission needed", "Run this once with ADB, then press OK again:\n\n$grantCmd", grantCmd)
            } else {
                try {
                    Settings.Global.putInt(contentResolver, key, if (readGlobal(key)) 0 else 1)
                } catch (e: Exception) {
                    toast("This TV did not allow that change")
                }
            }
        }
    }

    // -------------------------------------------------------------- apps

    private fun allPackages() = packageManager.getInstalledApplications(0)

    private fun countApps(disabled: Boolean) = allPackages().count { (!it.enabled) == disabled }

    private fun playState(): String {
        fun state(pkg: String) = try {
            if (packageManager.getApplicationInfo(pkg, 0).enabled) "on" else "OFF"
        } catch (e: Exception) {
            "missing"
        }
        return "Play services ${state("com.google.android.gms")}, Store ${state("com.android.vending")}"
    }

    private fun showAllApps() {
        val pm = packageManager
        val list = allPackages()
            .sortedWith(compareBy({ it.enabled }, { pm.getApplicationLabel(it).toString().lowercase() }))
        val labels = list.map { (if (it.enabled) "" else "[OFF] ") + pm.getApplicationLabel(it) }
        AlertDialog.Builder(this)
            .setTitle("All apps (disabled first)")
            .setItems(labels.toTypedArray()) { _, i ->
                val app = list[i]
                val opts = arrayOf("Open app info", if (app.enabled) "Copy disable command" else "Copy enable command")
                AlertDialog.Builder(this)
                    .setTitle(pm.getApplicationLabel(app).toString())
                    .setMessage(app.packageName)
                    .setItems(opts) { _, w ->
                        if (w == 0) {
                            go(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")),
                                Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)
                            )
                        } else {
                            val cmd = "adb shell pm ${if (app.enabled) "disable-user --user 0" else "enable"} ${app.packageName}"
                            copy(cmd)
                            toast("Copied: $cmd")
                        }
                    }
                    .show()
            }
            .show()
    }

    // ------------------------------------------------------------ helpers

    private fun ipAddress(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (!a.isLoopbackAddress && !h.contains(":")) return h
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return "not connected"
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("A-tv", text))
    }

    private fun showCopy(title: String, message: String, toCopy: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Copy command") { _, _ -> copy(toCopy); toast("Copied") }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun go(vararg intents: Intent?) {
        for (i in intents) {
            if (i == null) continue
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // try next
            }
        }
        toast("This TV blocks that screen")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(0, dp(20), 0, 0)
        })
    }

    private fun row(parent: LinearLayout, title: String, value: () -> String, onClick: () -> Unit) {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        v.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 18f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val valueView = TextView(this).apply {
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 16f
        }
        v.addView(valueView)
        parent.addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        v.setOnClickListener { onClick(); refreshAll() }
        refreshers.add { valueView.text = value() }
        rows.add(v)
    }

    private fun refreshAll() {
        refreshers.forEach { it() }
        root.background = Prefs.gradient(this)
        rows.forEach { it.background = Prefs.tileBackground(this) }
    }
}
