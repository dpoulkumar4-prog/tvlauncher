package com.example.mylauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import java.io.File

data class BgPreset(val name: String, val c1: Int, val c2: Int, val c3: Int)

/** All launcher customization lives here so Settings and the home screen share one source. */
object Prefs {

    val presets = listOf(
        BgPreset("Google TV dark", 0xFF0A0E17.toInt(), 0xFF111827.toInt(), 0xFF1B2638.toInt()),
        BgPreset("Ocean", 0xFF0B2A5B.toInt(), 0xFF1E5FAF.toInt(), 0xFF4B2A8F.toInt()),
        BgPreset("Sunset", 0xFF3B1C5A.toInt(), 0xFFB5416A.toInt(), 0xFFF2994A.toInt()),
        BgPreset("Forest", 0xFF06231A.toInt(), 0xFF145A3A.toInt(), 0xFF2E8B57.toInt()),
        BgPreset("Midnight", 0xFF05060F.toInt(), 0xFF111B3A.toInt(), 0xFF2A1F5E.toInt()),
        BgPreset("Graphite", 0xFF0F0F12.toInt(), 0xFF22242B.toInt(), 0xFF3A3D47.toInt()),
        BgPreset("Rose", 0xFF3A0F2B.toInt(), 0xFF8E2B63.toInt(), 0xFFD86AA5.toInt()),
        BgPreset("Black", 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt())
    )

    val accents = listOf(
        "Ice blue" to 0xFF9FE8FF.toInt(),
        "White" to 0xFFFFFFFF.toInt(),
        "Orange" to 0xFFFFA726.toInt(),
        "Pink" to 0xFFFF6FB5.toInt(),
        "Green" to 0xFF69F0AE.toInt(),
        "Purple" to 0xFFB388FF.toInt(),
        "Yellow" to 0xFFFFEB3B.toInt()
    )

    val clockSizes = listOf(56f, 80f, 104f)
    val tileScales = listOf(0.8f, 1.0f, 1.25f)
    val zooms = listOf(1.0f, 1.08f, 1.15f)
    val dims = listOf(0, 20, 40, 60, 80)

    fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun flag(ctx: Context, key: String, def: Boolean = true) = sp(ctx).getBoolean(key, def)
    fun setFlag(ctx: Context, key: String, v: Boolean) = sp(ctx).edit().putBoolean(key, v).apply()
    fun int(ctx: Context, key: String, def: Int) = sp(ctx).getInt(key, def)
    fun setInt(ctx: Context, key: String, v: Int) = sp(ctx).edit().putInt(key, v).apply()

    fun presetIndex(ctx: Context) = int(ctx, "bg_preset", 0).coerceIn(0, presets.size - 1)
    fun accentIndex(ctx: Context) = int(ctx, "accent", 0).coerceIn(0, accents.size - 1)
    fun accent(ctx: Context) = accents[accentIndex(ctx)].second
    fun dim(ctx: Context) = int(ctx, "dim", 30).coerceIn(0, 100)
    fun clockSize(ctx: Context) = clockSizes[int(ctx, "clock_size", 2).coerceIn(0, 2)]
    fun tileScale(ctx: Context) = tileScales[int(ctx, "tile_size", 1).coerceIn(0, 2)]
    fun zoom(ctx: Context) = zooms[int(ctx, "zoom", 2).coerceIn(0, 2)]
    fun columns(ctx: Context) = int(ctx, "columns", 6).coerceIn(3, 10)

    fun photoFile(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    fun gradient(ctx: Context): GradientDrawable {
        val p = presets[presetIndex(ctx)]
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(p.c1, p.c2, p.c3)
        )
    }

    // ---- glass, blur, animation, particles
    private val glassAlphas = listOf(0x0C, 0x1A, 0x2A, 0x40)
    private val blurRadii = listOf(0f, 8f, 16f, 28f)
    private val animDurations = listOf(90L, 140L, 260L)
    private val particleCounts = listOf(0, 14, 30, 50)

    fun lowPerf(ctx: Context) = flag(ctx, "lowperf", false)
    private fun glassAlpha(ctx: Context) = glassAlphas[int(ctx, "glass", 1).coerceIn(0, 3)]
    fun blur(ctx: Context) = blurRadii[int(ctx, "blur", 0).coerceIn(0, 3)]
    fun animMs(ctx: Context) = if (lowPerf(ctx)) 0L else animDurations[int(ctx, "anim_speed", 1).coerceIn(0, 2)]
    fun particles(ctx: Context) =
        if (lowPerf(ctx)) 0 else particleCounts[int(ctx, "particles", 1).coerceIn(0, 3)]

    private fun white(alpha: Int) = (alpha shl 24) or 0x00FFFFFF

    /** Frosted-glass look for a big panel (the dock). */
    fun glassPanel(ctx: Context): Drawable {
        val d = ctx.resources.displayMetrics.density
        val a = glassAlpha(ctx)
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(white(a + 0x10), white(a / 2))
        ).apply {
            setStroke((1 * d).toInt().coerceAtLeast(1), white(0x44))
            cornerRadius = 32 * d
        }
    }

    fun tileBackground(ctx: Context): Drawable {
        val d = ctx.resources.displayMetrics.density
        val a = glassAlpha(ctx)
        val acc = accent(ctx)
        val glow = (0x55 shl 24) or (acc and 0x00FFFFFF)
        val focused = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(glow, white(0x22))
        ).apply {
            setStroke((3 * d).toInt(), acc)
            cornerRadius = 18 * d
        }
        val normal = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(white(a + 0x08), white(a / 2))
        ).apply {
            setStroke((1 * d).toInt().coerceAtLeast(1), white(0x22))
            cornerRadius = 18 * d
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    // ---- recently opened apps
    fun recent(ctx: Context): List<String> =
        (sp(ctx).getString("recent", "") ?: "").split("|").filter { it.isNotEmpty() }

    fun pushRecent(ctx: Context, pkg: String) {
        val l = (listOf(pkg) + recent(ctx).filter { it != pkg }).take(8)
        sp(ctx).edit().putString("recent", l.joinToString("|")).apply()
    }

    // ---- app order and hidden apps
    fun customSort(ctx: Context) = flag(ctx, "sort_custom", false)
    fun order(ctx: Context): List<String> =
        (sp(ctx).getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }

    fun saveOrder(ctx: Context, list: List<String>) =
        sp(ctx).edit().putString("order", list.joinToString("|")).putBoolean("sort_custom", true).apply()

    fun hidden(ctx: Context): Set<String> =
        sp(ctx).getStringSet("hidden", emptySet()).orEmpty()

    fun setHidden(ctx: Context, s: Set<String>) =
        sp(ctx).edit().putStringSet("hidden", s).apply()

    /** Resets looks and layout; keeps your dock apps. */
    fun reset(ctx: Context) {
        val e = sp(ctx).edit()
        for (k in sp(ctx).all.keys) {
            if (k != "favorites" && k != "asked_default") e.remove(k)
        }
        e.apply()
        photoFile(ctx).delete()
    }
}
