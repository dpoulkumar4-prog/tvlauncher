package com.example.mylauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        // Focus lift: tile grows (amount set in Settings) and its label brightens.
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) Prefs.zoom(view.context) else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(140).start()
            view.elevation = if (hasFocus) 12f else 0f
            view.findViewById<TextView>(R.id.label).animate()
                .alpha(if (hasFocus) 1f else 0.55f).setDuration(140).start()
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        val ctx = holder.itemView.context
        val density = ctx.resources.displayMetrics.density
        val scale = Prefs.tileScale(ctx)
        val w = (160 * scale * density).toInt()
        val h = (90 * scale * density).toInt()

        holder.icon.layoutParams = holder.icon.layoutParams.also { it.width = w; it.height = h }
        holder.label.layoutParams = holder.label.layoutParams.also { it.width = w }
        holder.label.visibility = if (Prefs.flag(ctx, "show_labels")) View.VISIBLE else View.GONE
        holder.itemView.background = Prefs.tileBackground(ctx)

        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.itemView.setOnClickListener { onClick(app) }
        holder.itemView.setOnLongClickListener { onLongClick(app); true }
    }

    override fun getItemCount() = items.size
}
