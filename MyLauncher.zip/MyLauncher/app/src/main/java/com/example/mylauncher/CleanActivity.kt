package com.example.mylauncher

import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

class CleanActivity : AppCompatActivity() {

    private lateinit var speedValue: TextView
    private lateinit var linkInfo: TextView
    private lateinit var btnTest: Button
    private lateinit var usageToday: TextView
    private lateinit var usageMonth: TextView
    private lateinit var usageBoot: TextView
    private lateinit var btnUsage: Button
    private lateinit var cleanHint: TextView
    private lateinit var appList: RecyclerView

    private val adapter = AppAdapter(::openInfo, ::openInfo)

    /** System parts that must never be offered for disabling. */
    private val protectedPrefixes = listOf(
        "android", "com.android.", "com.google.android.gms", "com.google.android.gsf",
        "com.google.android.katniss", "com.google.android.tvlauncher",
        "com.cvte.settings", "com.cvte.tv.setting", "com.cvte.tv.launcher",
        "com.cvte.tv.provision", "com.cvte.tv.systemupgrade", "com.cvte.tvservice",
        "com.cvte.tv.api", "com.cvte.tv.globalui", "com.droidlogic", "com.amlogic"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_clean)

        speedValue = findViewById(R.id.speedValue)
        linkInfo = findViewById(R.id.linkInfo)
        btnTest = findViewById(R.id.btnTest)
        usageToday = findViewById(R.id.usageToday)
        usageMonth = findViewById(R.id.usageMonth)
        usageBoot = findViewById(R.id.usageBoot)
        btnUsage = findViewById(R.id.btnUsage)
        cleanHint = findViewById(R.id.cleanHint)
        appList = findViewById(R.id.appList)

        appList.layoutManager = GridLayoutManager(this, 6)
        appList.adapter = adapter

        btnTest.setOnClickListener { runSpeedTest() }
        btnUsage.setOnClickListener {
            tryStart(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        btnTest.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        refreshWifi()
        refreshUsage()
        loadBloat()
    }

    // ----------------------------------------------------------- Wi-Fi

    @Suppress("DEPRECATION")
    private fun refreshWifi() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        linkInfo.text = if (info != null && info.networkId != -1) {
            val bars = WifiManager.calculateSignalLevel(info.rssi, 5)
            "Link speed ${info.linkSpeed} Mbps  •  Signal $bars/4"
        } else {
            "Not connected to Wi-Fi (maybe on Ethernet)"
        }
    }

    private fun runSpeedTest() {
        btnTest.isEnabled = false
        speedValue.text = "Testing…"
        Thread {
            var result: String
            try {
                val conn = URL("https://speed.cloudflare.com/__down?bytes=25000000")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val buf = ByteArray(64 * 1024)
                var total = 0L
                val start = System.nanoTime()
                conn.inputStream.use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (System.nanoTime() - start > 8_000_000_000L) break
                    }
                }
                val secs = (System.nanoTime() - start) / 1e9
                result = if (secs > 0 && total > 0)
                    String.format(Locale.US, "%.0f Mbps", total * 8 / secs / 1_000_000.0)
                else "Failed"
            } catch (e: Exception) {
                result = "No internet"
            }
            runOnUiThread {
                speedValue.text = result
                btnTest.isEnabled = true
                refreshUsage()
            }
        }.start()
    }

    // ------------------------------------------------------ data usage

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun wifiBytes(from: Long): Long {
        return try {
            val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val b = nsm.querySummaryForDevice(
                ConnectivityManager.TYPE_WIFI, null, from, System.currentTimeMillis()
            )
            b.rxBytes + b.txBytes
        } catch (e: Exception) {
            -1L
        }
    }

    private fun refreshUsage() {
        val boot = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes()
        usageBoot.text = "Since last restart (all networks): ${fmt(boot)}"

        if (hasUsageAccess()) {
            btnUsage.visibility = View.GONE
            val day = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val month = (day.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
            usageToday.text = fmt(wifiBytes(day.timeInMillis))
            usageMonth.text = "This month: ${fmt(wifiBytes(month.timeInMillis))}"
        } else {
            btnUsage.visibility = View.VISIBLE
            usageToday.text = "--"
            usageMonth.text = "Allow usage access to see today and this month"
        }
    }

    private fun fmt(b: Long): String = when {
        b < 0 -> "--"
        b >= (1L shl 30) -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        else -> String.format(Locale.US, "%.0f MB", b / 1048576.0)
    }

    // ------------------------------------------------- maker's apps

    private fun loadBloat() {
        val pm = packageManager
        val tv = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val mobile = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = (pm.queryIntentActivities(tv, 0) + pm.queryIntentActivities(mobile, 0))
            .filter {
                val pkg = it.activityInfo.packageName
                (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    pkg != packageName &&
                    protectedPrefixes.none { p -> pkg.startsWith(p) }
            }
            .distinctBy { it.activityInfo.packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.activityInfo.loadBanner(pm) ?: it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
        adapter.submit(list)
        cleanHint.text = if (list.isEmpty())
            "No removable maker apps found. Nothing to clean."
        else
            "Open an app, then press Disable. Only disable apps you do not use. System parts are hidden to keep your TV safe."
    }

    private fun openInfo(app: AppInfo) {
        tryStart(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")),
            Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)
        )
    }

    private fun tryStart(vararg intents: Intent) {
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // try next
            }
        }
        Toast.makeText(this, "This TV blocks that screen", Toast.LENGTH_LONG).show()
    }
}
