package com.example.mylauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Random

/** Soft floating light particles. Draws nothing when count is 0 (low-performance mode). */
class ParticleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class P(var x: Float, var y: Float, val r: Float, val vx: Float, val vy: Float, val a: Int)

    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random()

    var count: Int = 0
        set(value) {
            field = value
            rebuild()
            invalidate()
        }

    init {
        isFocusable = false
        isClickable = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    private fun rebuild() {
        ps.clear()
        if (width == 0 || height == 0) return
        val d = resources.displayMetrics.density
        repeat(count) {
            ps.add(
                P(
                    rnd.nextFloat() * width,
                    rnd.nextFloat() * height,
                    (1.5f + rnd.nextFloat() * 3.5f) * d,
                    (rnd.nextFloat() - 0.5f) * 0.6f * d,
                    -(0.15f + rnd.nextFloat() * 0.5f) * d,
                    20 + rnd.nextInt(60)
                )
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (count == 0 || ps.isEmpty()) return
        for (p in ps) {
            p.x += p.vx
            p.y += p.vy
            if (p.y < -p.r) { p.y = height + p.r; p.x = rnd.nextFloat() * width }
            if (p.x < -p.r) p.x = width + p.r
            if (p.x > width + p.r) p.x = -p.r
            paint.color = (p.a shl 24) or 0x00FFFFFF
            canvas.drawCircle(p.x, p.y, p.r, paint)
        }
        postInvalidateOnAnimation()
    }
}
