# My Launcher (Android TV)

Apple-TV-style home screen for Android TV, made for remote/D-pad use.

## What is on screen
- Clock + date header
- Favorites row (hold OK on any app to add/remove)
- Tools row with shortcuts:
  - TV Settings / Android Settings / Manage all apps / Wi-Fi
  - Developer options (falls back to the About page: tap "Build" 7 times)
  - Fix Play Store / Fix Play services: open the App info page; press **Enable** there
  - Allow installs: lets this launcher install APK files
  - Install APK file: pick an .apk from the TV storage or USB and install it
- All apps grid (TV banners when apps provide them)

## Your TV (Amlogic, Android 13)
The report shows `com.android.vending` (Play Store) and `com.google.android.gms`
(Play services) as disabled. Enable **Play services first**, then Play Store, then
sign in again. Restart the TV after enabling.

## Install
No developer options? Put the built `.apk` on a USB stick, open it with the TV's
file manager, and allow "install unknown apps" when asked.
Build the APK in Android Studio: Build > Build APK(s) (app/build/outputs/apk/debug).

## Make it the home screen
If pressing Home does not offer a choice, open My Launcher from the TV's app list.
The TV maker blocked switching the default home (UNKNOWN_HOME in your report), so
this may not be possible without ADB.

## Limits
Android does not let any normal app turn on disabled apps, grant itself permissions,
or change the default home silently. The tools only open the right screens for you.
