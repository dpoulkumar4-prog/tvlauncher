package com.custom.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val colors = intArrayOf(Color.rgb(80,231,255), Color.rgb(255,112,180), Color.rgb(177,130,255), Color.rgb(255,190,80), Color.WHITE)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildSettings() }
    private fun panel() = GradientDrawable().apply { setColor(0xCC102B4B.toInt()); cornerRadius = 22f }
    private fun buildSettings() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(42, 28, 42, 28); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF063B5A.toInt(), 0xFF173B78.toInt(), 0xFF482A75.toInt())) }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(TextView(this).apply { text = "Launcher settings"; textSize = 30f; setTextColor(Color.WHITE); setPadding(0,0,0,18) })
        val greeting = EditText(this).apply { setSingleLine(); hint = "Greeting name (e.g. Techy Pathshala)"; setText(prefs.getString("greeting", "Your TV")); textSize = 18f; setTextColor(Color.WHITE); setHintTextColor(0xFFB9C9D8.toInt()); setPadding(18,14,18,14); background = panel() }
        root.addView(greeting, LinearLayout.LayoutParams(-1, -2))
        root.addView(button("Save greeting") { prefs.edit().putString("greeting", greeting.text.toString().ifBlank { "Your TV" }).apply(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() })
        root.addView(section("Clock"))
        val clock = Switch(this).apply { text = "Use 24-hour clock"; textSize = 18f; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("24h", false); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("24h", checked).apply() } }
        root.addView(clock)
        root.addView(section("Wallpaper and background"))
        root.addView(button("Choose wallpaper photo") { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }; startActivityForResult(i, 77) })
        root.addView(button("Use default blue-purple gradient") { prefs.edit().remove("wallpaper").apply(); Toast.makeText(this, "Default background selected", Toast.LENGTH_SHORT).show() })
        root.addView(section("Highlight colour"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        colors.forEach { color -> val v = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(3, Color.WHITE) }; isFocusable = true; setOnClickListener { prefs.edit().putInt("accent", color).apply(); Toast.makeText(this@SettingsActivity, "Highlight colour saved", Toast.LENGTH_SHORT).show() } }; row.addView(v, LinearLayout.LayoutParams(48,48).apply { setMargins(8,8,8,8) }) }
        root.addView(row)
        root.addView(section("Apps and dock"))
        root.addView(button("Reset dock to first six apps") { prefs.edit().remove("dock").apply(); Toast.makeText(this, "Dock reset", Toast.LENGTH_SHORT).show() })
        root.addView(TextView(this).apply { text = "Tip: On the home screen, focus an app and hold OK to add or remove it from the dock."; textSize = 15f; setTextColor(0xFFE4F2FF.toInt()); setPadding(0,10,0,16) })
        root.addView(section("About"))
        root.addView(TextView(this).apply { text = "My TV Launcher 1.0\nDesigned for Android TV 13 and remote-control navigation.\nThe original manufacturer launcher is not removed."; textSize = 15f; setTextColor(Color.WHITE) })
        root.addView(button("Back to home") { finish() })
    }
    private fun section(s: String) = TextView(this).apply { text = s; textSize = 21f; setTextColor(Color.WHITE); setPadding(0,22,0,10) }
    private fun button(s: String, action: () -> Unit) = TextView(this).apply { text = s; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(18,15,18,15); background = panel(); isFocusable = true; setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,7,0,7) } }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode, resultCode, data); if (requestCode == 77 && resultCode == RESULT_OK) { data?.data?.let { uri: Uri -> try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); prefs.edit().putString("wallpaper", uri.toString()).apply(); Toast.makeText(this, "Wallpaper saved. Return home to apply.", Toast.LENGTH_LONG).show() } catch (_: Exception) { Toast.makeText(this, "Could not save wallpaper permission", Toast.LENGTH_SHORT).show() } } } }
}
