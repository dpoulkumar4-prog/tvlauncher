package com.custom.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.InputStream
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var grid: GridLayout
    private var apps: List<android.content.pm.ResolveInfo> = emptyList()
    private val cyan = Color.rgb(80, 231, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        buildHome()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) buildHome() }

    private fun bg(color: Int, radius: Float, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; if (stroke != Color.TRANSPARENT) setStroke(3, stroke) }

    private fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD) }

    private fun buildHome() {
        val accent = prefs.getInt("accent", cyan)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(38, 22, 38, 18); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(5, 80, 113), Color.rgb(19, 75, 151), Color.rgb(70, 40, 126))) }
        setContentView(root)
        prefs.getString("wallpaper", null)?.let { raw -> try { contentResolver.openInputStream(Uri.parse(raw))?.use { stream -> root.background = BitmapDrawable(resources, BitmapFactory.decodeStream(stream)) } } catch (_: Exception) { } }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val greeting = prefs.getString("greeting", "Your TV") ?: "Your TV"
        left.addView(label("Good ${if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < 12) "Morning" else "Evening"}, $greeting", 21f, Color.WHITE, true))
        left.addView(label(SimpleDateFormat("EEEE, dd MMMM", Locale.getDefault()).format(Date()), 14f, 0xFFE5F6FF.toInt()))
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        val mem = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / (1024L * 1024L * 1024L)
        left.addView(label("Memory ${(mem.totalMem - mem.availMem) / (1024L*1024L)} MB used  •  Storage ${freeGb} GB free", 12f, 0xFFD1E8FF.toInt()))
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(pill("Inputs", accent) { openInputs() })
        actions.addView(pill(wifiName(), accent) { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) })
        actions.addView(pill("⚙ Settings", accent) { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) })
        top.addView(actions)
        root.addView(top)

        val clock = TextView(this).apply {
            text = SimpleDateFormat(if (prefs.getBoolean("24h", false)) "HH:mm" else "h:mm", Locale.getDefault()).format(Date())
            textSize = 86f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); setShadowLayer(18f, 0f, 3f, 0x6655DDFF)
        }
        root.addView(clock, LinearLayout.LayoutParams(-1, 0, 1f))
        val dockFrame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12); background = bg(0x5539DDF5, 28f) }
        dock = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        dockFrame.addView(dock)
        root.addView(dockFrame)
        val otherTitle = label("All apps", 17f, Color.WHITE, true).apply { setPadding(4, 13, 0, 7) }
        root.addView(otherTitle)
        grid = GridLayout(this).apply { columnCount = 6; useDefaultMargins = true }
        val scroll = ScrollView(this).apply { isFillViewport = false; addView(grid) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        loadApps()
        renderApps(accent)
    }

    private fun pill(text: String, accent: Int, action: () -> Unit) = TextView(this).apply {
        this.text = "  $text  "; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(10, 9, 10, 9); background = bg(0x55FFFFFF, 30f, 0x88FFFFFF.toInt()); isFocusable = true; isClickable = true; setOnClickListener { action() }; setOnFocusChangeListener { v, focused -> v.background = bg(if (focused) 0x8844DFFF.toInt() else 0x55FFFFFF, 30f, if (focused) accent else 0x88FFFFFF.toInt()) }
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val tvApps = pm.queryIntentActivities(intent, 0)
        val phoneApps = if (tvApps.isEmpty()) pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0) else tvApps
        apps = phoneApps.filter { it.activityInfo.packageName != packageName }.distinctBy { it.activityInfo.packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }
    }

    private fun renderApps(accent: Int) {
        dock.removeAllViews(); grid.removeAllViews()
        val chosen = prefs.getString("dock", "")!!.split(",").filter { it.isNotBlank() }
        val dockApps = if (chosen.isEmpty()) apps.take(6) else chosen.mapNotNull { p -> apps.find { it.activityInfo.packageName == p } }.take(8)
        dockApps.forEach { addAppTile(dock, it, accent, true) }
        apps.filterNot { a -> dockApps.any { it.activityInfo.packageName == a.activityInfo.packageName } }.forEach { addAppTile(grid, it, accent, false) }
        if (apps.isEmpty()) grid.addView(label("No launchable apps found. Check app visibility on this TV.", 18f))
    }

    private fun addAppTile(parent: ViewGroup, info: android.content.pm.ResolveInfo, accent: Int, isDock: Boolean) {
        val pm = packageManager
        val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(10, 8, 10, 8); background = bg(0xAAFFFFFF.toInt(), 15f); isFocusable = true; isClickable = true }
        val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(pm)); scaleType = ImageView.ScaleType.FIT_CENTER }
        tile.addView(icon, LinearLayout.LayoutParams(if (isDock) 54 else 46, if (isDock) 48 else 42))
        val name = label(info.loadLabel(pm).toString(), 11f, Color.DKGRAY, true).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        tile.addView(name, LinearLayout.LayoutParams(if (isDock) 100 else 112, -2))
        tile.setOnFocusChangeListener { v, focused -> v.background = bg(if (focused) 0xEEFFFFFF.toInt() else 0xAAFFFFFF.toInt(), 15f, if (focused) accent else Color.TRANSPARENT); if (focused) v.scaleX = 1.06f else v.scaleX = 1f; v.scaleY = if (focused) 1.06f else 1f }
        tile.setOnClickListener { launch(info) }
        tile.setOnLongClickListener { showTileMenu(info); true }
        val lp = if (isDock) LinearLayout.LayoutParams(0, 82, 1f).apply { setMargins(5, 0, 5, 0) } else GridLayout.LayoutParams().apply { width = 125; height = 90; setMargins(5, 3, 5, 3) }
        parent.addView(tile, lp)
    }

    private fun launch(info: android.content.pm.ResolveInfo) { try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER).setClassName(info.activityInfo.packageName, info.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { try { startActivity(packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)) } catch (_: Exception) { Toast.makeText(this, "Cannot open this app", Toast.LENGTH_SHORT).show() } } }

    private fun showTileMenu(info: android.content.pm.ResolveInfo) {
        val p = info.activityInfo.packageName; val current = prefs.getString("dock", "")!!.split(",").filter { it.isNotBlank() }.toMutableList()
        val inDock = current.contains(p)
        AlertDialog.Builder(this).setTitle(info.loadLabel(packageManager)).setItems(arrayOf(if (inDock) "Remove from dock" else "Add to dock", "App info")) { _, which ->
            if (which == 0) { if (inDock) current.remove(p) else if (current.size < 8) current.add(p); prefs.edit().putString("dock", current.joinToString(",")).apply(); buildHome() }
            else startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$p")))
        }.show()
    }

    private fun openInputs() { try { startActivity(Intent("android.settings.HDMI_SETTINGS")) } catch (_: Exception) { Toast.makeText(this, "Input settings are controlled by the TV manufacturer", Toast.LENGTH_LONG).show() } }
    private fun wifiName(): String { return try { val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager; val s = wm.connectionInfo.ssid; if (s == null || s == "<unknown ssid>") "Wi-Fi" else s.replace("\"", "") } catch (_: Exception) { "Wi-Fi" } }
}
