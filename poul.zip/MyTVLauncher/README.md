# My TV Launcher (Android TV)

A first native Android launcher project for the Amlogic `at30a6` TV (Android 13 / API 33).

## Included in version 1.0
- Android TV / Leanback app entry and HOME intent-filter (the TV may still restrict changing the default launcher).
- Large digital clock, greeting, date, memory/storage line.
- Wi-Fi name shortcut and Inputs shortcut (manufacturer input settings may not expose a standard intent).
- Installed TV app discovery and launch grid.
- First six apps shown in a dock by default.
- Hold/long-press an app tile to add/remove it from the dock or open its Android app-info page.
- Settings for greeting, 12/24-hour clock, wallpaper photo, accent/highlight colour, and dock reset.
- D-pad focus styling and OK/Enter activation.

## Build
Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK will be under `app/build/outputs/apk/debug/`.

This workspace does not include Android SDK/Gradle build tools, so no APK has been compiled or device-tested here. This is source code, not a verified installable APK.

## Install/test on TV
1. Build the debug APK in Android Studio.
2. Transfer it to the TV and install it (enable installation from the file manager only if you trust the APK you built).
3. Open **My TV Launcher** from the TV's apps list first.
4. Test app launching, remote navigation, wallpaper picker and settings.
5. Only if the TV offers a Home-app chooser, select My TV Launcher. Keep the CVTE launcher installed as fallback.

The TV report showed `UNKNOWN_HOME`, so the manufacturer firmware may block third-party default Home selection. This app cannot bypass that restriction without privileged/system access.

## Notes
- Memory/storage are approximate device-wide values from Android APIs.
- Wallpaper selection uses Android's document picker; some TV file pickers may not provide it.
- Wi-Fi name may display as `Wi-Fi` if Android privacy/firmware restrictions hide the SSID.
- Weather, internet speed test, data usage, HDMI input switching, and fully configurable app reordering are not implemented in this initial build.
