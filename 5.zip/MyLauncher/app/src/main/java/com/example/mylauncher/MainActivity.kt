package com.example.mylauncher

import android.app.ActivityManager
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var favRow: RecyclerView
    private lateinit var appGrid: RecyclerView
    private lateinit var greeting: TextView
    private lateinit var dateText: TextView
    private lateinit var statsText: TextView
    private lateinit var pillWifi: TextView

    private val favAdapter = AppAdapter(::launch, ::showOptions)
    private val gridAdapter = AppAdapter(::launch, ::showOptions)
    private val recentAdapter = AppAdapter(::launch, ::showOptions)
    private lateinit var recentRow: RecyclerView
    private lateinit var recentTitle: TextView

    private var allApps: List<AppInfo> = emptyList()
    private var fullList: List<AppInfo> = emptyList()
    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    /** Entries of the Tools pill: id to label. */
    private val tools = listOf(
        "default" to "Set as home screen",
        "cleaner" to "TV Cleaner (speed, data, remove apps)",
        "tvsettings" to "TV Settings",
        "settings" to "Android Settings",
        "dev" to "Developer options",
        "playstore" to "Fix Play Store",
        "gms" to "Fix Play services",
        "unknown" to "Allow installs",
        "apk" to "Install APK file",
        "apps" to "Manage all apps",
        "wifi" to "Wi-Fi settings"
    )

    // File picker used by the "Install APK" tool.
    private val apkPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { installApk(it) }
    }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        greeting = findViewById(R.id.greeting)
        dateText = findViewById(R.id.dateText)
        statsText = findViewById(R.id.statsText)
        pillWifi = findViewById(R.id.pillWifi)
        favRow = findViewById(R.id.favRow)
        appGrid = findViewById(R.id.appGrid)

        favRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        favRow.adapter = favAdapter

        appGrid.layoutManager = GridLayoutManager(this, 6)
        appGrid.adapter = gridAdapter

        recentRow = findViewById(R.id.recentRow)
        recentTitle = findViewById(R.id.recentTitle)
        recentRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recentRow.adapter = recentAdapter

        findViewById<View>(R.id.pillInputs).setOnClickListener { openInputs() }
        pillWifi.setOnClickListener { startActivity(Intent(this, CleanActivity::class.java)) }
        findViewById<View>(R.id.pillTools).setOnClickListener { showTools() }
        findViewById<View>(R.id.pillSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        // Opened from A-tv Settings with "Install an APK file"
        if (intent.getStringExtra("tool") == "apk") runTool("apk")

        // Startup: dark screen, logo glows in, then the home screen fades in.
        val splash = findViewById<View>(R.id.splash)
        if (savedInstanceState == null && Prefs.flag(this, "show_splash")) {
            splash.visibility = View.VISIBLE
            findViewById<View>(R.id.splashLogo).animate().alpha(1f).setDuration(800).withEndAction {
                splash.animate().alpha(0f).setStartDelay(500).setDuration(600)
                    .withEndAction { splash.visibility = View.GONE }.start()
            }.start()
        }
    }

    /** Applies everything chosen in Settings to the home screen. */
    private fun applyLook() {
        val photo = Prefs.photoFile(this)
        val bg = findViewById<android.widget.ImageView>(R.id.bgImage)
        val dimView = findViewById<View>(R.id.dimView)
        val frame = findViewById<View>(R.id.rootFrame)
        if (photo.exists()) {
            val bmp = android.graphics.BitmapFactory.decodeFile(photo.path)
            bg.setImageBitmap(bmp)
            bg.visibility = if (bmp != null) View.VISIBLE else View.GONE
            dimView.visibility = View.VISIBLE
            dimView.setBackgroundColor((Prefs.dim(this) * 255 / 100) shl 24)
        } else {
            bg.visibility = View.GONE
            dimView.visibility = View.GONE
        }
        frame.background = Prefs.gradient(this)

        // Photo blur (Android 12+), floating particles and glass dock.
        if (Build.VERSION.SDK_INT >= 31) {
            val r = Prefs.blur(this)
            bg.setRenderEffect(
                if (r > 0f) android.graphics.RenderEffect.createBlurEffect(
                    r, r, android.graphics.Shader.TileMode.CLAMP
                ) else null
            )
        }
        findViewById<ParticleView>(R.id.particles).count = Prefs.particles(this)
        findViewById<View>(R.id.dockContainer).background = Prefs.glassPanel(this)

        fun show(id: Int, key: String, def: Boolean = true) {
            findViewById<View>(id).visibility = if (Prefs.flag(this, key, def)) View.VISIBLE else View.GONE
        }
        show(R.id.greeting, "show_greeting")
        show(R.id.dateText, "show_date")
        show(R.id.statsText, "show_stats")
        show(R.id.clock, "show_clock")
        show(R.id.dockContainer, "show_dock")
        show(R.id.appGrid, "show_grid")
        show(R.id.pillInputs, "pill_inputs")
        show(R.id.pillWifi, "pill_wifi")
        show(R.id.pillTools, "pill_tools")

        val clock = findViewById<android.widget.TextClock>(R.id.clock)
        clock.textSize = Prefs.clockSize(this)
        if (Prefs.flag(this, "use24", false)) {
            clock.format24Hour = "HH:mm"; clock.format12Hour = "HH:mm"
        } else {
            clock.format24Hour = "h:mm"; clock.format12Hour = "h:mm"
        }

        (appGrid.layoutManager as GridLayoutManager).spanCount = Prefs.columns(this)
        accentColor = Prefs.accent(this)
        favAdapter.notifyDataSetChanged()
        gridAdapter.notifyDataSetChanged()
    }

    private var accentColor = 0

    override fun onResume() {
        super.onResume()
        applyLook()
        updateHeader()
        loadApps()
        if (!isDefaultHome() && !prefs.getBoolean("asked_default", false)) {
            prefs.edit().putBoolean("asked_default", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Make this your home screen?")
                .setMessage("Press Home on your remote to open A-tv.")
                .setPositiveButton("Yes") { _, _ -> requestDefaultHome() }
                .setNegativeButton("Not now", null)
                .show()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        appGrid.scrollToPosition(0)
        firstFocusTarget().requestFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher never exits on Back.
    }

    private fun firstFocusTarget(): View = when {
        favRow.isShown && favRow.childCount > 0 -> favRow
        appGrid.isShown -> appGrid
        else -> findViewById(R.id.pillSettings)
    }

    // -------------------------------------------------------------- header

    @Suppress("DEPRECATION")
    private fun updateHeader() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greeting.text = when {
            h < 12 -> "Good Morning"
            h < 17 -> "Good Afternoon"
            else -> "Good Evening"
        }
        dateText.text = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date())

        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val totalMb = mi.totalMem / 1048576
        val usedMb = totalMb - mi.availMem / 1048576
        val freeGb = StatFs(Environment.getDataDirectory().path).availableBytes / 1073741824.0
        statsText.text = String.format(
            Locale.US, "Memory %d / %d MB  •  Storage %.0f GB free", usedMb, totalMb, freeGb
        )

        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        pillWifi.text = if (info != null && info.networkId != -1 && info.linkSpeed > 0)
            "Wi-Fi  ${info.linkSpeed} Mbps" else "Wi-Fi"
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        val pm = packageManager
        val tv = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val mobile = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(tv, 0) + pm.queryIntentActivities(mobile, 0)

        val sorted = resolved
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.activityInfo.loadBanner(pm) ?: it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }

        // "My order": apps you moved come first in your order, new apps follow A to Z.
        fullList = if (Prefs.customSort(this)) {
            val order = Prefs.order(this)
            sorted.sortedBy { a -> order.indexOf(a.packageName).let { if (it < 0) Int.MAX_VALUE else it } }
        } else sorted

        val hidden = Prefs.hidden(this)
        allApps = fullList.filter { it.packageName !in hidden }

        gridAdapter.submit(allApps)
        refreshFavorites()
        refreshRecent()
        appGrid.post { firstFocusTarget().requestFocus() }
    }

    /** Dock = apps you pinned; until you pin any, it shows the first six apps. */
    private fun refreshFavorites() {
        val pinned = prefs.getStringSet("favorites", emptySet()).orEmpty()
        val favs = allApps.filter { it.packageName in pinned }
        favAdapter.submit(favs.ifEmpty { allApps.take(6) })
    }

    private fun launch(app: AppInfo) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
        intent?.let {
            Prefs.pushRecent(this, app.packageName)
            startActivity(it)
        }
    }

    private fun refreshRecent() {
        val names = Prefs.recent(this)
        val list = names.mapNotNull { n -> allApps.firstOrNull { it.packageName == n } }
        recentAdapter.submit(list)
        val vis = if (Prefs.flag(this, "show_recent") && list.isNotEmpty()) View.VISIBLE else View.GONE
        recentRow.visibility = vis
        recentTitle.visibility = vis
    }

    private fun showOptions(app: AppInfo) {
        val pinned = prefs.getStringSet("favorites", emptySet()).orEmpty().toMutableSet()
        val isPinned = app.packageName in pinned
        val items = arrayOf(
            if (isPinned) "Remove from dock" else "Add to dock",
            "Move earlier",
            "Move later",
            "Hide this app",
            "App info",
            "Uninstall"
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        if (isPinned) pinned.remove(app.packageName) else pinned.add(app.packageName)
                        prefs.edit().putStringSet("favorites", pinned).apply()
                        refreshFavorites()
                    }
                    1 -> moveApp(app, -1)
                    2 -> moveApp(app, 1)
                    3 -> {
                        Prefs.setHidden(this, Prefs.hidden(this) + app.packageName)
                        loadApps()
                        toast("Hidden. Show all again in Settings > Hidden apps")
                    }
                    4 -> openAppDetails(app.packageName)
                    5 -> tryStart(
                        Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${app.packageName}"))
                    )
                }
            }
            .show()
    }

    private fun moveApp(app: AppInfo, delta: Int) {
        val names = fullList.map { it.packageName }.toMutableList()
        val from = names.indexOf(app.packageName)
        val to = (from + delta).coerceIn(0, names.size - 1)
        if (from < 0 || from == to) return
        names.removeAt(from)
        names.add(to, app.packageName)
        Prefs.saveOrder(this, names)
        loadApps()
        appGrid.post {
            val pos = allApps.indexOfFirst { it.packageName == app.packageName }
            if (pos >= 0) appGrid.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus()
        }
    }

    // --------------------------------------------------------------- tools

    private fun showTools() {
        AlertDialog.Builder(this)
            .setTitle("Tools")
            .setItems(tools.map { it.second }.toTypedArray()) { _, which ->
                runTool(tools[which].first)
            }
            .show()
    }

    /** Lists the TV's real inputs (HDMI 1, HDMI 2, TV...) and switches to the one you pick. */
    private fun openInputs() {
        val tim = getSystemService(Context.TV_INPUT_SERVICE) as? android.media.tv.TvInputManager
        val inputs = try {
            tim?.tvInputList.orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
        val fallback = arrayOf(
            packageManager.getLaunchIntentForPackage("com.cvte.tv.media"),
            packageManager.getLaunchIntentForPackage("com.droidlogic.tvinput"),
            packageManager.getLaunchIntentForPackage("com.cvte.tv.globalui")
        )
        if (inputs.isEmpty()) {
            tryStart(*fallback)
            return
        }
        val labels = inputs.map { (it.loadLabel(this)?.toString() ?: it.id) }
        AlertDialog.Builder(this)
            .setTitle("Inputs")
            .setItems(labels.toTypedArray()) { _, i ->
                val info = inputs[i]
                val uri = if (info.isPassthroughInput)
                    android.media.tv.TvContract.buildChannelUriForPassthroughInput(info.id)
                else
                    android.media.tv.TvContract.Channels.CONTENT_URI
                tryStart(Intent(Intent.ACTION_VIEW, uri), *fallback)
            }
            .show()
    }

    private fun runTool(id: String) {
        when (id) {
            "default" -> requestDefaultHome()
            "cleaner" -> startActivity(Intent(this, CleanActivity::class.java))
            "tvsettings" -> tryStart(
                packageManager.getLaunchIntentForPackage("com.cvte.settings"),
                packageManager.getLaunchIntentForPackage("com.cvte.tv.setting"),
                Intent(Settings.ACTION_SETTINGS)
            )
            "settings" -> tryStart(Intent(Settings.ACTION_SETTINGS))
            "dev" -> tryStart(
                Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                Intent(Settings.ACTION_DEVICE_INFO_SETTINGS) // tap "Build" 7 times here
            )
            "playstore" -> openAppDetails("com.android.vending")
            "gms" -> openAppDetails("com.google.android.gms")
            "unknown" -> tryStart(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            "apk" -> {
                if (!packageManager.canRequestPackageInstalls()) {
                    toast("First allow this launcher to install apps")
                    runTool("unknown")
                } else {
                    try {
                        apkPicker.launch(
                            arrayOf("application/vnd.android.package-archive", "application/octet-stream")
                        )
                    } catch (e: ActivityNotFoundException) {
                        toast("No file picker on this TV. Install a file manager app first.")
                    }
                }
            }
            "apps" -> tryStart(
                Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
                Intent(Settings.ACTION_APPLICATION_SETTINGS)
            )
            "wifi" -> tryStart(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    // ------------------------------------------------------ default home

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    /** Asks Android to make this the home app; falls back to the system settings screens. */
    private fun requestDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                try {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                } catch (e: Exception) {
                    // fall through to settings
                }
            }
        }
        tryStart(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
    }

    // ------------------------------------------------------------- helpers

    /** Opens the system "App info" page; for a disabled app this page shows an Enable button. */
    private fun openAppDetails(pkg: String) {
        tryStart(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")),
            Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_SETTINGS)
        )
    }

    private fun installApk(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        tryStart(i)
    }

    /** Tries each intent in order and stops at the first one this TV can actually open. */
    private fun tryStart(vararg intents: Intent?) {
        for (i in intents) {
            if (i == null) continue
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // try the next one
            }
        }
        toast("This TV blocks that screen")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
