package com.example.mylauncher

import android.content.ActivityNotFoundException
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.FileOutputStream

/** Full customization screen. Every change is saved at once and applied when you go back Home. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var root: ScrollView
    private val refreshers = mutableListOf<() -> Unit>()
    private val rowViews = mutableListOf<View>()

    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { savePhoto(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = ScrollView(this).apply { isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(27), dp(48), dp(27))
        }
        root.addView(col)
        setContentView(root)

        col.addView(TextView(this).apply {
            text = "Customize"
            setTextColor(Color.WHITE)
            textSize = 30f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Press OK on a line to change it. Changes show on the home screen."
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 14f
        })

        // ---------------------------------------------------------- Background
        section(col, "Background")
        row(col, "Colour theme", {
            if (Prefs.photoFile(this).exists()) "Photo in use" else Prefs.presets[Prefs.presetIndex(this)].name
        }) {
            choose("Colour theme", Prefs.presets.map { it.name }) { i ->
                Prefs.setInt(this, "bg_preset", i)
                Prefs.photoFile(this).delete() // picking a colour theme replaces the photo
            }
        }
        row(col, "Wallpaper photo", { if (Prefs.photoFile(this).exists()) "On" else "None" }) {
            choose("Wallpaper photo", listOf("Choose a photo", "Remove photo")) { i ->
                if (i == 0) {
                    try {
                        photoPicker.launch(arrayOf("image/*"))
                    } catch (e: ActivityNotFoundException) {
                        toast("No photo picker on this TV. Use a colour theme instead.")
                    }
                } else {
                    Prefs.photoFile(this).delete()
                }
            }
        }
        row(col, "Photo darkness", { "${Prefs.dim(this)}%" }) {
            choose("Photo darkness", Prefs.dims.map { "$it%" }) { i -> Prefs.setInt(this, "dim", Prefs.dims[i]) }
        }
        row(col, "Highlight colour", { Prefs.accents[Prefs.accentIndex(this)].first }) {
            choose("Highlight colour", Prefs.accents.map { it.first }) { i -> Prefs.setInt(this, "accent", i) }
        }

        // ------------------------------------------------------- Home screen
        section(col, "What shows on the home screen")
        toggle(col, "Greeting", "show_greeting")
        toggle(col, "Date", "show_date")
        toggle(col, "Memory and storage line", "show_stats")
        toggle(col, "Clock", "show_clock")
        row(col, "Clock size", { listOf("Small", "Medium", "Large")[Prefs.int(this, "clock_size", 2).coerceIn(0, 2)] }) {
            choose("Clock size", listOf("Small", "Medium", "Large")) { i -> Prefs.setInt(this, "clock_size", i) }
        }
        toggle(col, "24-hour clock", "use24", def = false)
        toggle(col, "App dock row", "show_dock")
        toggle(col, "All apps grid", "show_grid")
        toggle(col, "Inputs button", "pill_inputs")
        toggle(col, "Wi-Fi button", "pill_wifi")
        toggle(col, "Tools button", "pill_tools")

        // --------------------------------------------------------------- Apps
        section(col, "Apps and movement")
        row(col, "Apps per row", { "${Prefs.columns(this)}" }) {
            choose("Apps per row", listOf("4", "5", "6", "7", "8")) { i -> Prefs.setInt(this, "columns", 4 + i) }
        }
        row(col, "Tile size", { listOf("Small", "Medium", "Large")[Prefs.int(this, "tile_size", 1).coerceIn(0, 2)] }) {
            choose("Tile size", listOf("Small", "Medium", "Large")) { i -> Prefs.setInt(this, "tile_size", i) }
        }
        row(col, "Focus zoom when you move", { listOf("Off", "Small", "Big")[Prefs.int(this, "zoom", 2).coerceIn(0, 2)] }) {
            choose("Focus zoom", listOf("Off", "Small", "Big")) { i -> Prefs.setInt(this, "zoom", i) }
        }
        toggle(col, "Show app names", "show_labels")
        row(col, "App order", { if (Prefs.customSort(this)) "My order" else "A to Z" }) {
            choose("App order (hold OK on an app to move it)", listOf("A to Z", "My order")) { i ->
                Prefs.setFlag(this, "sort_custom", i == 1)
            }
        }
        row(col, "Hidden apps", { "${Prefs.hidden(this).size} hidden, OK to show all" }) {
            Prefs.setHidden(this, emptySet())
            toast("All apps are visible again")
        }

        // ------------------------------------------------------ Glass and motion
        section(col, "Glass and motion")
        row(col, "Glass transparency", { listOf("Clear", "Light", "Medium", "Frosted")[Prefs.int(this, "glass", 1).coerceIn(0, 3)] }) {
            choose("Glass transparency", listOf("Clear", "Light", "Medium", "Frosted")) { i -> Prefs.setInt(this, "glass", i) }
        }
        row(col, "Wallpaper blur (Android 12+)", { listOf("Off", "Soft", "Medium", "Strong")[Prefs.int(this, "blur", 0).coerceIn(0, 3)] }) {
            choose("Wallpaper blur", listOf("Off", "Soft", "Medium", "Strong")) { i -> Prefs.setInt(this, "blur", i) }
        }
        row(col, "Animation speed", { listOf("Fast", "Normal", "Slow")[Prefs.int(this, "anim_speed", 1).coerceIn(0, 2)] }) {
            choose("Animation speed", listOf("Fast", "Normal", "Slow")) { i -> Prefs.setInt(this, "anim_speed", i) }
        }
        row(col, "Floating particles", { listOf("Off", "Few", "Normal", "Many")[Prefs.int(this, "particles", 1).coerceIn(0, 3)] }) {
            choose("Floating particles", listOf("Off", "Few", "Normal", "Many")) { i -> Prefs.setInt(this, "particles", i) }
        }
        toggle(col, "3D tilt on selected app", "tilt")
        toggle(col, "Recent apps row", "show_recent")
        toggle(col, "Startup animation", "show_splash")
        toggle(col, "Low-performance mode (no motion or particles)", "lowperf", def = false)

        // ------------------------------------------------------------- System
        section(col, "System and developer")
        row(col, "Developer options", { "OK to open" }) {
            go(
                android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                android.content.Intent(android.provider.Settings.ACTION_DEVICE_INFO_SETTINGS)
            )
        }
        row(col, "Unlock developer options", { "About page: press OK on Build 7 times" }) {
            go(android.content.Intent(android.provider.Settings.ACTION_DEVICE_INFO_SETTINGS))
        }
        row(col, "Make A-tv the home screen", { "" }) {
            go(
                android.content.Intent(android.provider.Settings.ACTION_HOME_SETTINGS),
                android.content.Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
            )
        }
        row(col, "Play services (enable)", { "App info" }) { appInfo("com.google.android.gms") }
        row(col, "Play Store (enable)", { "App info" }) { appInfo("com.android.vending") }
        row(col, "All apps", { "" }) {
            go(android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS))
        }
        row(col, "Wi-Fi", { "" }) {
            go(android.content.Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))
        }
        row(col, "Android settings", { "" }) {
            go(android.content.Intent(android.provider.Settings.ACTION_SETTINGS))
        }
        row(col, "TV Cleaner (speed, data, maker apps)", { "" }) {
            startActivity(android.content.Intent(this, CleanActivity::class.java))
        }

        // -------------------------------------------------------------- Reset
        section(col, "Reset")
        row(col, "Reset looks and layout", { "" }) {
            AlertDialog.Builder(this)
                .setTitle("Reset everything?")
                .setMessage("Colours, wallpaper and layout go back to the start. Your dock apps stay.")
                .setPositiveButton("Reset") { _, _ -> Prefs.reset(this); refreshAll() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        refreshAll()
        rowViews.firstOrNull()?.requestFocus()
    }

    // ------------------------------------------------------------- UI helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(0, dp(20), 0, 0)
        })
    }

    private fun row(parent: LinearLayout, title: String, value: () -> String, onClick: () -> Unit) {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        v.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 18f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val valueView = TextView(this).apply {
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 16f
        }
        v.addView(valueView)
        parent.addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        v.setOnClickListener {
            onClick()
            refreshAll()
        }
        refreshers.add { valueView.text = value() }
        rowViews.add(v)
    }

    private fun toggle(parent: LinearLayout, title: String, key: String, def: Boolean = true) {
        row(parent, title, { if (Prefs.flag(this, key, def)) "On" else "Off" }) {
            Prefs.setFlag(this, key, !Prefs.flag(this, key, def))
        }
    }

    private fun choose(title: String, labels: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels.toTypedArray()) { _, i ->
                onPick(i)
                refreshAll()
            }
            .show()
    }

    private fun refreshAll() {
        refreshers.forEach { it() }
        root.background = Prefs.gradient(this)
        rowViews.forEach { it.background = Prefs.tileBackground(this) }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /** Opens the first screen this TV allows. */
    private fun go(vararg intents: android.content.Intent) {
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // try next
            }
        }
        toast("This TV blocks that screen")
    }

    private fun appInfo(pkg: String) = go(
        android.content.Intent(
            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$pkg")
        ),
        android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)
    )

    // ------------------------------------------------------------ wallpaper

    private fun savePhoto(uri: Uri) {
        Thread {
            var ok = false
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 1400) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                }
                if (bmp != null) {
                    FileOutputStream(Prefs.photoFile(this)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                toast(if (ok) "Wallpaper set" else "Could not read that picture")
                refreshAll()
            }
        }.start()
    }
}
