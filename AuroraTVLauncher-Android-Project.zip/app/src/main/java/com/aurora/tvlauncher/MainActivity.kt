package com.aurora.tvlauncher

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var grid: GridLayout
    private val prefs by lazy { getSharedPreferences("aurora", MODE_PRIVATE) }
    private var accent = Color.rgb(65,205,255)
    private var wallpaper: Uri? = null
    private val tiles = mutableListOf<View>()
    private var selected = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accent = prefs.getInt("accent", accent)
        prefs.getString("wallpaper", null)?.let { wallpaper = Uri.parse(it) }
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(38, 22, 38, 18)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF06294D.toInt(), 0xFF174B91.toInt(), 0xFF552C91.toInt()))
        }
        wallpaper?.let { try { root.background = android.graphics.drawable.BitmapDrawable(resources, contentResolver.openInputStream(it)) } catch (_: Exception) {} }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greeting = if (hour < 12) "Good Morning" else if (hour < 17) "Good Afternoon" else "Good Evening"
        info.addView(text(greeting, 22, Color.WHITE, true))
        info.addView(text(SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date()), 14, 0xFFD9E8FF.toInt()))
        info.addView(text("Aurora TV Launcher", 12, 0xFFBBD5F4.toInt()))
        header.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(pill("⚙ Settings") { settings() })
        header.addView(pill("▣ Inputs") { inputs() })
        root.addView(header)

        val clock = text(SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()), 76, Color.WHITE, true)
        clock.gravity = Gravity.CENTER
        root.addView(clock, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(text("FAVOURITES", 12, Color.WHITE, true))
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(10, 10, 10, 10); background = shape(0x553FFFFFF, 24)
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, 78).apply { bottomMargin = 14 })

        root.addView(text("ALL APPS", 12, Color.WHITE, true))
        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { columnCount = 6 }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadApps()
    }

    private fun loadApps() {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        var apps = pm.queryIntentActivities(leanback, 0)
        if (apps.isEmpty()) apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val list = apps.distinctBy { it.activityInfo.packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }
        val saved = prefs.getString("dock", "")!!.split("|").filter { it.isNotBlank() }
        val favs = if (saved.isEmpty()) list.take(6).map { it.activityInfo.packageName } else saved
        dock.removeAllViews()
        favs.take(6).forEach { pkg -> list.firstOrNull { it.activityInfo.packageName == pkg }?.let {
            dock.addView(tile(it, true), LinearLayout.LayoutParams(0, 58, 1f).apply { marginEnd = 7 })
        } }
        grid.removeAllViews(); tiles.clear()
        list.forEach { item ->
            val v = tile(item, false)
            grid.addView(v, GridLayout.LayoutParams().apply {
                width = 0; height = 105; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(7, 7, 7, 7)
            })
            tiles.add(v)
        }
        if (tiles.isNotEmpty()) tiles[0].requestFocus()
    }

    private fun tile(item: android.content.pm.ResolveInfo, compact: Boolean): LinearLayout {
        val pkg = item.activityInfo.packageName
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(5, 5, 5, 5); background = shape(0x44FFFFFF, 17)
            isFocusable = true
            val icon = try { item.loadIcon(packageManager) } catch (_: Exception) { null }
            if (icon != null) addView(ImageView(this@MainActivity).apply { setImageDrawable(icon) },
                LinearLayout.LayoutParams(if (compact) 32 else 44, if (compact) 32 else 44))
            addView(text(item.loadLabel(packageManager).toString(), if (compact) 10 else 12, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            setOnClickListener { openApp(pkg) }
            setOnLongClickListener { appMenu(pkg, item.loadLabel(packageManager).toString()); true }
            setOnFocusChangeListener { v, focus ->
                v.background = shape(if (focus) 0xAAFFFFFF.toInt() else 0x44FFFFFF, 17, if (focus) accent else Color.TRANSPARENT)
                v.alpha = if (focus) 1f else .88f
            }
        }
    }

    private fun openApp(pkg: String) {
        try { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }
        catch (_: Exception) { Toast.makeText(this, "Unable to open app", Toast.LENGTH_SHORT).show() }
    }

    private fun appMenu(pkg: String, name: String) {
        AlertDialog.Builder(this).setTitle(name).setItems(arrayOf("Open", "Add to favourites", "App info")) { _, which ->
            when (which) {
                0 -> openApp(pkg)
                1 -> {
                    val old = prefs.getString("dock", "")!!.split("|").filter { it.isNotBlank() }.toMutableList()
                    old.remove(pkg); old.add(0, pkg); prefs.edit().putString("dock", old.take(6).joinToString("|")).apply(); loadApps()
                }
                2 -> startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
            }
        }.show()
    }

    private fun settings() {
        AlertDialog.Builder(this).setTitle("Aurora TV settings")
            .setItems(arrayOf("Choose wallpaper", "Highlight colour", "Reset wallpaper", "Android settings")) { _, n ->
                when (n) {
                    0 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 9)
                    1 -> AlertDialog.Builder(this).setTitle("Highlight colour").setItems(arrayOf("Blue", "Purple", "Mint", "Orange", "Pink")) { _, c ->
                        accent = intArrayOf(0xFF41CDFF.toInt(), 0xFFB46EFF.toInt(), 0xFF50E6AA.toInt(), 0xFFFFA546.toInt(), 0xFFFF69B4.toInt())[c]
                        prefs.edit().putInt("accent", accent).apply(); render()
                    }.show()
                    2 -> { wallpaper = null; prefs.edit().remove("wallpaper").apply(); render() }
                    3 -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                }
            }.show()
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9 && resultCode == RESULT_OK) data?.data?.let {
            wallpaper = it
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("wallpaper", it.toString()).apply(); render()
        }
    }

    private fun inputs() {
        AlertDialog.Builder(this).setTitle("Inputs")
            .setItems(arrayOf("HDMI 1", "HDMI 2", "Live TV", "TV settings")) { _, n ->
                if (n == 3) startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                else Toast.makeText(this, "Input switching depends on your TV firmware.", Toast.LENGTH_LONG).show()
            }.show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (tiles.isNotEmpty()) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_RIGHT -> { selected = (selected + 1) % tiles.size; tiles[selected].requestFocus(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { selected = (selected - 1 + tiles.size) % tiles.size; tiles[selected].requestFocus(); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { selected = (selected + 6) % tiles.size; tiles[selected].requestFocus(); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { selected = (selected - 6 + tiles.size) % tiles.size; tiles[selected].requestFocus(); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun pill(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(15, 11, 15, 11); background = shape(0x553FFFFFF, 28, 0x66FFFFFF)
        isFocusable = true; setOnClickListener { action() }
    }
    private fun shape(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); if (stroke != Color.TRANSPARENT) setStroke(3, stroke)
    }
}
