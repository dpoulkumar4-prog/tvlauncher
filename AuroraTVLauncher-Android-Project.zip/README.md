# Aurora TV Launcher
Android TV launcher prototype. Features: clock/date/greeting, installed app grid, favourites dock, remote D-pad focus, wallpaper picker and accent colour setting.

Build with Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and Android SDK 35.
